package mx.ghr.test.cmd.apps.test.generic;

import java.math.BigDecimal;


public class MethodReferenceA {
    public MethodReferenceA() {
        super();
    }

    @SuppressWarnings("org.adfemg.audits.java.system-out-usage")
    public static void addNumbers() {
        System.out.println("Adding Numbers!");
    }
        
    public void justCall() {
        
    }
    
    @ProceadureData(id = "altaFiso", fields = {"fisoName", "fisoID", "amount"})
    @SuppressWarnings("org.adfemg.audits.java.system-out-usage")
    public void withAnnotations(String anyString, Integer anyInteger, BigDecimal anyBigDecimal) {
        System.out.println("anyString: " + anyString + " anyInteger: " + anyInteger + " anyBigDecimal: " + anyBigDecimal);
    }
}
