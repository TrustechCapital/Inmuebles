package mx.ghr.test.cmd.apps;

import mx.ghr.test.cmd.apps.test.impl.MethodCallTest;


public class MainCMD {
    
    public MainCMD() {
        super();
    }

    @SuppressWarnings({ "org.adfemg.audits.java.system-exit-usage", "org.adfemg.audits.java.system-out-usage" })
    public static void main(String[] args) {
        
        try {
        
            MethodCallTest mct = new MethodCallTest();
            mct.doTest();
            
        } catch(Exception e) {
            e.printStackTrace();
        }
        
        System.out.println("\nProcess ended!");
        System.exit(0);
    }    

}
