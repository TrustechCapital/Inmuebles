package mx.ghr.test.cmd.apps.test.impl;

import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import mx.ghr.test.cmd.apps.TestObject;
import mx.ghr.test.cmd.apps.test.generic.MethodReferenceA;
import mx.ghr.test.cmd.apps.test.generic.ParameterInfo;
import mx.ghr.test.cmd.apps.test.generic.ProceadureData;
import mx.ghr.test.cmd.apps.test.generic.ProceadureInfo;

public class MethodCallTest implements TestObject {
    
    Class[] theClasses = new Class[]{MethodReferenceA.class};
        
    HashMap<String, ProceadureInfo> tesMapping = new HashMap<>();
    
    HashMap<String, String> parametersMapping = new HashMap<>();
    
    public MethodCallTest() {
        super();
    }

    @Override
    @SuppressWarnings("oracle.jdeveloper.java.semantic-warning")
    public boolean doTest() {
        
        init();
        
        try {
            ProceadureInfo pi = tesMapping.get("altaFiso");
            if(pi != null) {
                
                List<Object> paramArray = new ArrayList<>();
                
                for(ParameterInfo param : pi.getParameters()) {
                    String pv = parametersMapping.get(param.getId());
                    Object value = param.getType().getConstructor(String.class).newInstance(pv);
                    paramArray.add(value);
                }
                
                Object procObj = pi.getTheClass().newInstance();
                pi.getTheMethod().invoke(procObj, paramArray.toArray());
            }
        
        } catch(Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    @SuppressWarnings("oracle.jdeveloper.java.semantic-warning")
    public void init() {

        parametersMapping.put("fisoName", "El FISO de la Muerte");
        parametersMapping.put("fisoID", "2");
        parametersMapping.put("amount", "1234567.89");
            
        try {
            
            for(Class c : theClasses) {
                for(Method m : c.getMethods()) {
                    
                    ProceadureData pd = m.getAnnotation(ProceadureData.class);
                    
                    if(pd != null && pd.id() != "") {

                        String methodID = pd.id();
                        String[] fields = pd.fields();
                            
                        ArrayList<ParameterInfo> parameters = new ArrayList<>();

                        ProceadureInfo pi = new ProceadureInfo();
                        pi.setTheClass(c);
                        pi.setTheMethod(m);

                        Class[] pt = m.getParameterTypes();
                        for(int i = 0; i < pt.length; i++) {
                            parameters.add(new ParameterInfo(fields[i], pt[i]));
                        }
                        
                        pi.setParameters(parameters);
                        tesMapping.put(methodID, pi);
                    }
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
